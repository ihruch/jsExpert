export default class LoginController { 
    constructor(model, view, observer) {
        this.model = model;
        this.view = view;
    } 

    bindEvents() { }

    init() { }
    
}
