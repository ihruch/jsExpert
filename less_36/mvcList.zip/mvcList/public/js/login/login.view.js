export default class LoginView  {        
    constructor() {}
    
    init (items) {}
    
    buildView () {}

    getItemToSave () {}

    setSavedData (data) {}

    setUpdatedData (data) {}
}

    