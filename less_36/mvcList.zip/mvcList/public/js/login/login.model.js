export default class LoginModel {
    constructor() {  }

    getData() {
      
    }
    
    saveData(item) {         
        
    }
    
    updateData(counter) {
        
    }

}
 
