//=require components/1.js

const alpha = true;

console.log('test working');


console.log('test uglify');
console.log(alpha);