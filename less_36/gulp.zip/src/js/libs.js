console.log('test libs');
console.log('test uglify');